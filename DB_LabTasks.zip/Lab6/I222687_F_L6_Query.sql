USE I222687_F_L6

/*Task#3*/
/*
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Employee')
BEGIN
    CREATE TABLE Employee (
        emp_number INT PRIMARY KEY,
        name VARCHAR(50),
        job VARCHAR(50),
        manager INT,
        hire_date DATE,
        salary DECIMAL(10,2)
    )
END

/*IF NOT EXISTS ( SELECT 1 FROM sys.columns WHERE name = 'department_number' AND Object_ID = Object_ID(N'Employee'))*/ /*In this query we do not need this object_ID since we only have one table, but if we have multiple tables it's better to specify the table, to avoid any ambiguity*/
IF NOT EXISTS ( SELECT 1 FROM sys.columns WHERE name = 'department_number')
BEGIN
	ALTER TABLE Employee
	ADD department_number INT
END

/*INSERT INTO employee (emp_number, name, job, manager, hire_date, salary, department_number) /*If you are adding values for all the columns of the table, you do not need to specify the column names*/
VALUES
(7369, 'SMITH', 'CLERK', 7902, '1993-06-13', 800, 20),
(7499, 'ALLEN', 'SALESMAN', 7698, '1998-08-15', 1600, 30),
(7521, 'WARD', 'SALESMAN', 7698, '1996-03-26', 1250, 30),
(7566, 'JONES', 'MANAGER', 7839, '1995-10-31', 2975, 20),
(7698, 'BLAKE', 'MANAGER', 7839, '1992-06-11', 2850, 30),
(7782, 'CLARK', 'MANAGER', 7839, '1993-05-14', 2450, 10),
(7788, 'SCOTT', 'ANALYST', 7566, '1996-03-05', 3000, 20),
(7839, 'KING', 'PRESIDENT', NULL, '1990-06-09', 5000, 10),
(7844, 'TURNER', 'SALESMAN', 7698, '1995-06-04', 1500, 30),
(7876, 'ADAMS', 'CLERK', 7788, '1999-06-04', 1100, 20),
(7900, 'JAMES', 'CLERK', 7698, '2000-06-23', 950, 30),
(7902, 'FORD', 'ANALYST', 7566, '1997-12-05', 3000, 20),
(7934, 'MILLER', 'CLERK', 7782, '2000-01-21', 1300, 10);*/

SELECT * 
FROM Employee

SELECT name, emp_number, salary 
FROM Employee

SELECT name, emp_number, salary * 4 AS salaryX4
FROM Employee

SELECT DISTINCT job
FROM Employee

SELECT name, department_number, hire_date
FROM Employee
ORDER BY department_number

SELECT *
FROM Employee
WHERE manager IN (7698, 7566) AND salary > 1500

SELECT *
FROM Employee
WHERE department_number IN (20, 30)

SELECT *
FROM Employee
WHERE manager IS NULL

SELECT emp_number, name, job 
FROM Employee
WHERE salary BETWEEN 1500 and 2500

SELECT name, job 
FROM Employee
WHERE name like '%LL'

SELECT name
FROM Employee
WHERE name like '%S%'
*/

/*Task#6*/

IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Students')
BEGIN
	CREATE TABLE Students (
	studentId INT IDENTITY(1,1) PRIMARY KEY,
	firstName VARCHAR(20),
	lastName VARCHAR(20),
	major VARCHAR(15),
	yearOfStudy INT,
	GPA DECIMAL(3,2),
	enrollmentDate DATE
	)
END

/*
INSERT INTO Students (firstName, lastName, major, yearOfStudy, GPA, enrollmentDate)
VALUES ('Shabeeb', 'Asghar', NULL, 2, 3.5, '2019-01-15'),
       ('Bilal', 'Habib', 'Mathematics', 3, 3.8, '2021-09-20'),
       ('Ahmed', 'Murtaza', 'Biology', 1, 1.2, '2022-03-05'),
       ('Daniyal', 'Jutt', 'Physics', 4, 1.9, '2021-12-10'),
       ('Arbaz', 'Butt', 'Biology', 2, 3.4, '2022-02-28'),
       ('Sheryar', 'Kiyani', 'English', 3, 3.6, '2021-11-15'),
       ('Abdul', 'Faheem', 'English', 1, 3.1, '2022-01-05'),
       ('Faraz', 'Hayder', 'Art', 4, 3.7, '2021-10-25'),
       ('Ahmed', 'Ali', 'Mathematics', 2, 4, '2022-03-10'),
       ('Ali', 'Hassan', 'Psychology', 3, 3.5, '2025-12-30');
*/

SELECT *
FROM Students

SELECT firstName + ' ' + lastName AS FullName
FROM Students

SELECT firstName, lastName, GPA
FROM Students 
WHERE GPA > 3.5

SELECT studentId, firstName, major
FROM Students
ORDER BY studentId, major DESC

SELECT *
FROM Students 
WHERE major IS NULL

SELECT lastName, major, year(enrollmentDate) AS year
FROM Students 
WHERE lastName IN ('Ali', 'Hassan')
ORDER BY year(enrollmentDate)

SELECT lastName, major, GPA
FROM Students
WHERE major = 'Biology'
ORDER BY lastName

SELECT lastName, enrollmentDate 
FROM Students
WHERE enrollmentDate LIKE '2021%'

SELECT *
FROM Students
WHERE year(enrollmentDate) BETWEEN 2020 AND 2024

SELECT major, AVG(GPA) AS AvgGPA
FROM Students
WHERE major IS NOT NULL
GROUP BY major

SELECT firstName, lastName, GPA
FROM Students
WHERE GPA =
(
SELECT MAX(GPA)
FROM Students
)

SELECT firstName + ' ' + lastName AS FullName
FROM Students
WHERE GPA < 2

