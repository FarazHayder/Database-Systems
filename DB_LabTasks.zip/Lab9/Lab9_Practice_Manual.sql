-- -- Create Department table
-- CREATE TABLE Department (
--     DepartmentID INT PRIMARY KEY,
--     DepartmentName NVARCHAR(50) NOT NULL
-- );

-- -- Create Employee table
-- CREATE TABLE Employee (
--     EmployeeID INT PRIMARY KEY,
--     FirstName NVARCHAR(50) NOT NULL,
--     LastName NVARCHAR(50) NOT NULL,
--     DepartmentID INT,
--     CONSTRAINT FK_DepartmentID FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID)
-- );


-- -- Insert data into Department table
-- INSERT INTO Department (DepartmentID, DepartmentName)
-- VALUES
--     (1, 'IT'),
--     (2, 'HR'),
--     (3, 'Finance');

-- -- Insert data into Employee table
-- INSERT INTO Employee (EmployeeID, FirstName, LastName, DepartmentID)
-- VALUES
--     (1, 'Ali', 'Khan', 1),
--     (2, 'Sana', 'Ahmed', 2),
--     (3, 'Fahad', 'Raza', 1),
--     (4, 'Zoya', 'Malik', 3),
--     (5, 'Ahmed', 'Ali', 1),
--     (6, 'Sadia', 'Khan', 2);



-- select * from Employee;
-- select * from Department;

-- CREATE PROCEDURE showEmployeeTableData
-- AS
-- BEGIN
-- 	SELECT *
-- 	FROM Employee;
-- END

-- DROP PROCEDURE showEmployeeTableData;

EXEC showEmployeeTableData;

-- CREATE PROCEDURE showEmployeeTableDataWithFirstNameParameter @name VARCHAR(30)
-- AS
-- BEGIN
-- 	SELECT *
-- 	FROM Employee
-- 	WHERE FirstName = @name;
-- END

-- DROP PROCEDURE showEmployeeTableDataWithFirstNameParameter;

EXEC showEmployeeTableDataWithFirstNameParameter @NAME = Ali;
