-- Display the data in the tables
SELECT * FROM Students;
SELECT * FROM Courses;
SELECT * FROM Enrollments;

-- Task 1
-- ALTER TABLE Enrollments
-- ADD Semester VARCHAR(30);

-- CREATE PROCEDURE EnrollStudent @StudentID INT, @CourseID INT, @Semester VARCHAR(50), @Grade VARCHAR(2)
-- AS
-- BEGIN
-- 	INSERT INTO Enrollments
-- 	VALUES (
-- 		(
-- 			SELECT MAX(EnrollmentID)
-- 			FROM Enrollments
-- 		) + 1,
-- 		@StudentID,
-- 		@CourseID,
-- 		GETDATE(),
-- 		@Grade,
-- 		@Semester
-- 	);
-- END

EXEC EnrollStudent @StudentId = 2, @CourseId = 2, @semester = 'first', @Grade = 'A+';

-- SELECT *
-- FROM Enrollments;

-- Task 2
-- ALTER TABLE Courses
-- ADD CourseStatus VARCHAR(10);

-- ALTER TABLE Courses
-- ADD AvailableSeats INT;

-- UPDATE Courses
-- SET CourseStatus = 'opened', AvailableSeats = '10'
-- WHERE Credits = 3;

SELECT *
FROM Courses;

-- CREATE TRIGGER UpdateCourseCapacity
-- ON Enrollments
-- AFTER INSERT
-- AS
-- BEGIN
-- 	DECLARE @courseID INT;
-- 	SELECT @courseID = CourseID
-- 	FROM inserted;

-- 	UPDATE Courses
-- 	SET AvailableSeats = AvailableSeats - 1
-- 	WHERE CourseID = @courseID;

-- 	UPDATE Courses
-- 	SET CourseStatus = 'Closed'
-- 	WHERE AvailableSeats = 0;
-- END

-- DROP TRIGGER UpdateCourseCapacity;

