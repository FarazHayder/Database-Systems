use Lab12_10lakhRows;

Create table employees
(
    id int primary key identity,
    [name] nvarchar (50),
    [email] nvarchar (50),
    Department nvarchar (50)
    )

SET NOCOUNT ON
DECLARE @counter int=1

while (@counter <=1000000)
begin
    Declare @name nvarchar (50) = 'abc' + RTRIM(@counter)
    Declare @email nvarchar (50) = 'abc' + RTRIM(@counter) + '@nu.edu.pk'
    Declare @dept nvarchar (50) = 'Dept' + RTRIM(@counter)

    insert into employees values (@name, @email, @dept)

    Set @counter = @counter +1

    if (@counter % 100000 = 0)
        print RTRIM(@counter) + ' Row inserted'
END

select * from employees

select * from employees where id= 192560

select * from employees where email= 'abc8@nu.edu.pk'

select * from employees where name='abc92560'


Create nonClustered index IX_employees_name
on [dbo].[employees]([name])